#!/usr/bin/env bash

set -e

# Define installation directory
PODSENV_ROOT="$HOME/.podsenv"
BIN_DIR="$PODSENV_ROOT/bin"

echo "Installing podsenv..."

# Create necessary directories
mkdir -p "$PODSENV_ROOT/versions"
mkdir -p "$PODSENV_ROOT/shims"
mkdir -p "$BIN_DIR"
mkdir -p "$PODSENV_ROOT/default_gem_home"

# Copy the podsenv script
cp ./podsenv "$BIN_DIR/podsenv"
chmod +x "$BIN_DIR/podsenv"

echo "podsenv installed to $BIN_DIR"

echo "\nNow, add the following lines to your shell configuration file (e.g., ~/.bashrc, ~/.zshrc):"
echo "\n# podsenv configuration"
echo "export PATH=\"$BIN_DIR:$PODSENV_ROOT/shims:\$PATH\""
echo "eval \"\$(podsenv init -)\""
echo "\nAfter adding, run \"source ~/.bashrc\" (or your shell config file) to apply the changes."

# Run rehash to ensure shims are generated (even if no versions are installed yet)
"$BIN_DIR/podsenv" rehash

echo "Installation complete!"


